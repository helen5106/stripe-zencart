<?php 
/**
 * This file is used to do the refund functionality from stripe.com
 */
require('includes/application_top.php');

require(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/p_stripe/init.php');

$api_key = MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_SECRET_KEY;
if(MODULE_PAYMENT_P_STRIPE_TESTMODE == 'Test') {
  $api_key = MODULE_PAYMENT_P_STRIPE_TESTING_SECRET_KEY;
}

$amount = $_POST['amount'];
// For zero-decimal currencies, we use the regular denomination. For example, to charge ¥1, you should set amount=1 (1 JPY), since ¥1 is the smallest currency unit.
$zero_decimal = 100;
$zero_decimal_currencies = array('BIF', 'DJF', 'JPY', 'KRW', 'PYG', 'VND', 'XAF', 'XPF', 'CLP', 'GNF', 'KMF', 'MGA', 'RWF', 'VUV', 'XOF');
if(in_array($_POST['currency'], $zero_decimal_currencies)) {
  $zero_decimal = 1;
}
$amount = $amount*$zero_decimal;

try {
  
    $stripe = new \Stripe\StripeClient($api_key);

    $refund = $stripe->refunds->create(
      ['payment_intent' => $_POST['charge_id'], 'amount' => $amount]
    );

  // update status
  $sql_data_array = array('orders_status' => (int)MODULE_PAYMENT_P_STRIPE_ORDER_REFUND_STATUS_ID);
  zen_db_perform(TABLE_ORDERS, $sql_data_array, 'update', 'orders_id = ' . (int)$_POST['orders_id']);
  
  $refunded = $refund->amount;
  // add a new comment
  $sql_data_array = array(
    'orders_id' => (int)$_POST['orders_id'],
    'orders_status_id' => (int)MODULE_PAYMENT_P_STRIPE_ORDER_REFUND_STATUS_ID,
    'comments' => 'Stripe refunded: ' . ($refunded/$zero_decimal),
    'date_added' => 'now()'
  );
  zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
  
  // update stripe_data table
  $sql_data_array = array(
    //'stripe_charge_id' => $refund->id,
    'stripe_amount_refunded' => $refunded
  );
  zen_db_perform(DB_PREFIX . 'stripe_data', $sql_data_array, 'update', 'orders_id = ' . (int)$_POST['orders_id']);
  //echo '<pre>';var_dump($refund);
  echo 'Refunded: ' . ($refunded/$zero_decimal);
} catch(Exception $e) {
  echo 'Error: '.  $e->getMessage(). "<br />\n";
}