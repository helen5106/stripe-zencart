<?php
/**
 * Stripe Payments method class
 *
 * @package paymentMethod
 * @copyright 2012 Blue-Toucan.co.uk
 * @copyright Copyright 2003-2012 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @Please direct any suggestions/bugs/comments to Blue Toucan
 *
 * Stripe Payments USD/CAN
 * You must have SSL active on your server to use this in live mode
 *
 */


define('MODULE_PAYMENT_P_STRIPE_TEXT_TITLE', 'Stripe Payment');
define('MODULE_PAYMENT_P_STRIPE_TEXT_TITLE2', 'Stripe Payment');
define('MODULE_PAYMENT_P_STRIPE_ERROR_TITLE', 'Stripe Payment Error');
define('MODULE_PAYMENT_P_STRIPE_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.stripe.com" target="_blank" style="text-decoration: underline; font-weight: bold;">Visit the Stripe Website (opens in new window)</a>');		
