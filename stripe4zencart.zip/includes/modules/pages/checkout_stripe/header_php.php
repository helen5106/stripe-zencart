<?php
/**
 * checkout_payment header_php.php
 *
 * @package page
 * @copyright Copyright 2003-2019 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: mc12345678 2019 Apr 30 Modified in v1.5.6c $
 */
 
require DIR_WS_MODULES . zen_get_module_directory('require_languages.php');

$breadcrumb->add("Checkout Stripe");

unset($_SESSION['paymentIntent']);


if ( !isset($_SESSION['payment']) || empty($_SESSION['payment']) ) {
    $messageStack->add('header', ERROR_CART_UPDATE, 'error');
    zen_redirect(zen_href_link(FILENAME_SHOPPING_CART));
}

require DIR_WS_CLASSES . 'order.php';
$order = new order;

