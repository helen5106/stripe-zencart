<?php
/**
 * admin subtemplate for Stripe payment method
 *
 * @package paymentMethod
 * @copyright Copyright 2003-2010 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @copyright Portions Copyright 2004 DevosC.com
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 */
//var_dump($data->fields);

$output = '<td><table cellpadding="5" cellspacing="0" border="1" style="border-collapse:collapse; background:#eee;">';
$output .= '<tr>';

$order_amount = $data->fields['stripe_amount'];
$refunded = $data->fields['stripe_amount_refunded'];
// For zero-decimal currencies, we use the regular denomination. For example, to charge ¥1, you should set amount=1 (1 JPY), since ¥1 is the smallest currency unit.
$zero_decimal = 100;
$zero_decimal_currencies = array('BIF', 'DJF', 'JPY', 'KRW', 'PYG', 'VND', 'XAF', 'XPF', 'CLP', 'GNF', 'KMF', 'MGA', 'RWF', 'VUV', 'XOF');
if(in_array($data->fields['stripe_currency'], $zero_decimal_currencies)) {
  $zero_decimal = 1;
}
$order_amount = $order_amount/$zero_decimal;
$refunded = $refunded/$zero_decimal;

$output .= '<td valign="top">';
$output .= '<div class="field"><label style="display:inline-block; width:100px; line-height:22px;">ID:</label> <a target="_blank" href="https://dashboard.stripe.com/search?query=' . $data->fields['stripe_payment_intent'] . '">' . $data->fields['stripe_payment_intent'] . '</a></div>';

if($refunded == 0) {
  $output .= '<div class="field">';
  $output .= '<form name="stripe-form-refund" id="stripe-form-refund" onsubmit="javascript:window.open(\'\', \'formpost\', \'width=400,height=500,scrollbars=yes\')" action="' . HTTP_SERVER . DIR_WS_CATALOG . 'p_stripe_callback_api.php" method="post" target="formpost">';
  $output .= '<label style="display:inline-block; width:100px; line-height:22px;">Amount:</label> ' . '<input type="text" name="amount" value="' . $order_amount . '" size="10" />' . '<button type="submit">Refund</button>';
  $output .= zen_draw_hidden_field('orders_id', $data->fields['orders_id']) . zen_draw_hidden_field('charge_id', $data->fields['stripe_payment_intent']) . zen_draw_hidden_field('currency', $data->fields['stripe_currency']);
  $output .= '</form>';
  $output .= '</div>';
} else {
  $output .= '<div class="field"><label style="display:inline-block; width:100px; line-height:22px;">Amount:</label> ' . ($order_amount - $refunded) . '</div>';
}
$output .= '<div class="field"><label style="display:inline-block; width:100px; line-height:22px;">Refund:</label> ' . $refunded . '</div>';
$output .= '<div class="field"><label style="display:inline-block; width:100px; line-height:22px;">Currency:</label> ' . $data->fields['stripe_currency'] . '</div>';
$output .= '<div class="field"><label style="display:inline-block; width:100px; line-height:22px;">Create Time:</label> ' . $data->fields['created_at'] . '</div>';
//$output .= '<div class="field"><label style="display:inline-block; width:100px; line-height:22px;">Fingerprint:</label> ' . $data->fields['stripe_fingerprint'] . '</div>';
//$output .= '<div class="field"><label style="display:inline-block; width:100px; line-height:22px;">CVC Check:</label> ' . $data->fields['stripe_cvc_check'] . '</div>';
$output .= '</td>';

$output .= '</tr>';
$output .= '</table></td>';