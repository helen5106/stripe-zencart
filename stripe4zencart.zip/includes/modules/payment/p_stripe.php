<?php
// Stripe API
require(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/p_stripe/init.php');
/**
 * Stripe Payments method class
 *
 * REQUIRES PHP 5.4 or newer
 *
 * @package square
 * @copyright Copyright 2003-2019 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id:Modified in v1.5.6c $
 */

class p_stripe extends base {
  
  var $code, $title, $description, $enabled, $stripe_response, $sort_order, $_logDir, $api_key;
  
  // class constructor
  function __construct() {
    global $order, $messageStack, $db;
    $this->code            = 'p_stripe';
    $this->api_version     = 'Stripe Payment';
    $this->title           = MODULE_PAYMENT_P_STRIPE_TEXT_TITLE;
    $this->description     = MODULE_PAYMENT_P_STRIPE_TEXT_DESCRIPTION;
    $this->sort_order      = MODULE_PAYMENT_P_STRIPE_SORT_ORDER;
    $this->enabled         = ((MODULE_PAYMENT_P_STRIPE_STATUS == 'True') ? true : false);
    $_SESSION['transaction_data'] = '';
		
    $this->_logDir = DIR_FS_LOGS;
    
    $this->api_key = MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_SECRET_KEY;
    if(MODULE_PAYMENT_P_STRIPE_TESTMODE == 'Test') {
      $this->api_key = MODULE_PAYMENT_P_STRIPE_TESTING_SECRET_KEY;
    }
    \Stripe\Stripe::setApiKey($this->api_key);
    
    //$this->form_action_url = '';
    if (IS_ADMIN_FLAG === true) {
    
      if (!function_exists('curl_init')) $this->title .= '<strong><span class="alert"> CURL NOT FOUND. Cannot Use.</span></strong>';
      
      if ( MODULE_PAYMENT_P_STRIPE_TESTING_SECRET_KEY == '' || MODULE_PAYMENT_P_STRIPE_TESTING_PUBLISHABLE_KEY == '' || MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_SECRET_KEY == '' || MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_PUBLISHABLE_KEY == ''){
        $this->title .= '<strong><span class="alert"> One of your Stripe API keys is missing.</span></strong>';
      }        
    }
    
    if ((int)MODULE_PAYMENT_P_STRIPE_ORDER_STATUS_ID > 0) {
      $this->order_status = MODULE_PAYMENT_P_STRIPE_ORDER_STATUS_ID;
    }
    
    if (is_object($order)) $this->update_status();
    
    $this->form_action_url = zen_href_link('checkout_stripe', '', 'SSL');

  }
    
  // class methods
  function update_status() {
    global $order, $db;
    
    if ($this->enabled && (int)MODULE_PAYMENT_P_STRIPE_ZONE > 0 && isset($order->billing['country']['id'])) {
      $check_flag = false;
      $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_P_STRIPE_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
      while (!$check->EOF) {
        if ($check->fields['zone_id'] < 1) {
          $check_flag = true;
          break;
        } elseif ($check->fields['zone_id'] == $order->billing['zone_id']) {
          $check_flag = true;
          break;
        }
        $check->MoveNext();
      }

      if ($check_flag == false) {
        $this->enabled = false;
      }
    }
  }
    
  /**
   * JS validation which does error-checking of data-entry if this module is selected for use
   * (Number, Owner Lengths)
   *
   * @return string
   */
  function javascript_validation() {

    return '';
  }
    
	/**
   * Display Credit Card Information Submission Fields on the Checkout Payment Page
   *
   * @return array
   */
  function selection() {
        global $current_page_base,$template;

      return array('id' => $this->code,
                   'module' =>'<img src="/includes/modules/payment/p_stripe/stripe.png" style="height: 50px;vertical-align: middle;">',
            );

  }
	
  /**
   * Evaluates the Credit Card Type for acceptance and the validity of the Credit Card Number & Expiration Date
   *
   */
  function pre_confirmation_check() {
		
		return false;
  }

  /**
   * Display Credit Card Information on the Checkout Confirmation Page
   *
   * @return array
   */
  function confirmation() {

		return array('title' => MODULE_PAYMENT_P_STRIPE_TEXT_DESCRIPTION);
    
  }
  
  /**
   * Build the data and actions to process when the "Submit" button is pressed on the order-confirmation screen.
   * This sends the data to the payment gateway for processing.
   * (These are hidden fields on the checkout confirmation page)
   *
   * @return string
   */
  function process_button() {
    global $order, $currencies;
    
    $process_button_string = '';
    
    return $process_button_string;
  }
  
  /**
   * Store the CC info to the order and process any results that come back from the payment gateway
   *
   */
  function before_process() {
    global $messageStack, $currencies, $order, $db;
        
        if ( isset($_SESSION['paymentIntent']) && $_SESSION['paymentIntent'] != 'Error' ) {
            $stripe = new \Stripe\StripeClient(
              $this->api_key
            );
            $resp = $stripe->paymentIntents->retrieve(
              $_SESSION['paymentIntent'],
              []
            );
            if ( $resp->status == 'succeeded' && $_GET['redirect_status'] == $resp->status ) {
                $_SESSION['transaction_data'] = $resp;
                unset($_SESSION['paymentIntent']);
                
            } else {
                $messageStack->add_session('checkout_payment', 'You should pay the order first.', 'error');
                zen_redirect(zen_href_link('checkout_payment', '', 'SSL', true, false));
            }
            
            //$this->_debug(var_export($resp, 1));
            
        } else {
            $messageStack->add_session('checkout_payment', 'You should pay the order first.', 'error');
            zen_redirect(zen_href_link('checkout_payment', '', 'SSL', true, false));
        }

        
    return false;
  }
  
	/**
   * Post-processing activities
   *
   * @return boolean
   */
  function after_process() {
    global $insert_id, $db, $order;
		
    if (MODULE_PAYMENT_STRIPE_CURRENCY == 'Selected Currency') {
      $currency = $_SESSION['currency'];
    } else {
      $currency = MODULE_PAYMENT_STRIPE_CURRENCY;
    }
    
    //$this->notify('NOTIFY_PAYMENT_AUTHNETSIM_POSTPROCESS_HOOK');
    $sql = "insert into " . TABLE_ORDERS_STATUS_HISTORY . " (comments, orders_id, orders_status_id, customer_notified, date_added) values (:orderComments, :orderID, :orderStatus, -1, now() )";
    $currency_comment = '';

    $sql = $db->bindVars($sql, ':orderComments', 'Credit Card payment.  transaction_id: ' . $_SESSION['transaction_data']->id . ' ' . $currency_comment, 'string');
    $sql = $db->bindVars($sql, ':orderID', $insert_id, 'integer');
    $sql = $db->bindVars($sql, ':orderStatus', MODULE_PAYMENT_P_STRIPE_ORDER_STATUS_ID, 'integer');
    $db->Execute($sql);
    
    
    $sql_data_array = array(
      'orders_id' => zen_db_prepare_input($insert_id),
      'stripe_payment_intent' => zen_db_prepare_input($_SESSION['transaction_data']->id),
      'customers_id' => zen_db_prepare_input($_SESSION['customer_id']),
      'stripe_amount' => zen_db_prepare_input($_SESSION['transaction_data']->amount),
      'stripe_amount_refunded' => 0,
      'stripe_currency' => strtoupper(zen_db_prepare_input($_SESSION['transaction_data']->currency)),
      'created_at'     => date('Y-m-d H:i:s'),
    );
    zen_db_perform(DB_PREFIX . 'stripe_data', $sql_data_array);
    
    unset($_SESSION['transaction_data']);
    
    return false;
  }
 
  function check() {
    global $db;
    if (!isset($this->_check)) {
      $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_P_STRIPE_STATUS'");
      $this->_check = $check_query->RecordCount();
    }
    return $this->_check;
  }
  
	/**
    * Build admin-page components
    *
    * @param int $zf_order_id
    * @return string
    */
  function admin_notification($zf_order_id) {
    global $db;
    $output = '';
    $sql = "select * from " . DB_PREFIX . "stripe_data where orders_id = ".(int)$zf_order_id;
    $data = $db->Execute($sql);
    //var_dump($data);
    if ($data->RecordCount() > 0 && file_exists(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/p_stripe/p_stripe_admin_notification.php')) {
      require(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/p_stripe/p_stripe_admin_notification.php');
    }
    return $output;
  }

    function _debug($errorMessage){
        
        $file = $this->_logDir . '/' . 'stripe_' . date('YmdHis') . '.log';
        $fp = @fopen($file, 'a');
        @fwrite($fp, $errorMessage);
        @fclose($fp);
    }  
    
  /**
   * Install the payment module and its configuration settings
   *
   */
  function install() {
    global $db;
    
    if (!defined('MODULE_PAYMENT_P_STRIPE_STATUS')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable Stripe Module', 'MODULE_PAYMENT_P_STRIPE_STATUS', 'True', 'Do you want to accept stripe payments?', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_TESTING_SECRET_KEY')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Testing Secret Key', 'MODULE_PAYMENT_P_STRIPE_TESTING_SECRET_KEY', '', 'Enter your testing secret key. You can get it at stripe dashboard.', '6', '3', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_TESTING_PUBLISHABLE_KEY')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Testing Publishable Key', 'MODULE_PAYMENT_P_STRIPE_TESTING_PUBLISHABLE_KEY', '', 'Enter your testing publishable key. You can get it at stripe dashboard.', '6', '6', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_SECRET_KEY')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Live Secret Key', 'MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_SECRET_KEY', '', 'Enter your live secret key. You can get it at stripe dashboard.', '6', '10', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_PUBLISHABLE_KEY')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Live Publishable Key', 'MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_PUBLISHABLE_KEY', '', 'Enter your live publishable key. You can get it at stripe dashboard.', '6', '15', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_TESTMODE')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Transaction Mode', 'MODULE_PAYMENT_P_STRIPE_TESTMODE', 'Test', 'Transaction mode used for processing orders', '6', '18', 'zen_cfg_select_option(array(\'Test\', \'Production\'), ', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_CURRENCY')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Stripe Currency', 'MODULE_PAYMENT_P_STRIPE_CURRENCY', 'Selected Currency', 'The currency that your Stripe account is setup to handle - currently only a choice between USD and CAD - <b>make sure that your store is operating in the same currency!!</b>', '6', '50', 'zen_cfg_select_option(array(\'Selected Currency\', \'USD\', \'CAD\', \'EUR\',\'GBP\',\'AUD\'), ', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_USE_CVV')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Request CVV Number', 'MODULE_PAYMENT_P_STRIPE_USE_CVV', 'True', 'Do you want to ask the customer for the card\'s CVV number', '6', '20', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_SAVE_CC')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Save Credit Card Token', 'MODULE_PAYMENT_P_STRIPE_SAVE_CC', 'False', 'If you set to true, your customers do not need to fill out their card for the next payment.', '6', '22', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_ORDER_STATUS_ID')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Status', 'MODULE_PAYMENT_P_STRIPE_ORDER_STATUS_ID', '2', 'Set the status of orders made with this payment module to this value', '6', '25', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_ORDER_REFUND_STATUS_ID')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Refund Status', 'MODULE_PAYMENT_P_STRIPE_ORDER_REFUND_STATUS_ID', '1', 'Set the status of orders refunded made with this payment module to this value', '6', '28', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_ZONE')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_P_STRIPE_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '30', 'zen_get_zone_class_title', 'zen_cfg_pull_down_zone_classes(', now())");
    if (!defined('MODULE_PAYMENT_P_STRIPE_SORT_ORDER')) $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_P_STRIPE_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '6', '35', now())");
   
   //new database table
    $db->Execute("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "stripe_data` (
                  `stripe_id` int(11) NOT NULL auto_increment,
                  `orders_id` int(11) NOT NULL,
                  `customers_id` int(11) NOT NULL,
                  `stripe_payment_intent` varchar(64) NOT NULL,
                  `stripe_amount` int(11) NOT NULL,
                  `stripe_amount_refunded` int(11) default 0,
                  `stripe_currency` varchar(6) NOT NULL,
                  `created_at` varchar(32) NOT NULL,
                  PRIMARY KEY  (`stripe_id`)
                ) AUTO_INCREMENT=1;");
    
                
  }
  
  function remove() {
      global $db;
      $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
      $db->Execute("DROP TABLE IF EXISTS  `" . DB_PREFIX . "stripe_data`");
  }
  
  function keys() {
      return array(
        'MODULE_PAYMENT_P_STRIPE_STATUS',
        'MODULE_PAYMENT_P_STRIPE_ZONE',
        'MODULE_PAYMENT_P_STRIPE_ORDER_STATUS_ID',
        'MODULE_PAYMENT_P_STRIPE_ORDER_REFUND_STATUS_ID',
        'MODULE_PAYMENT_P_STRIPE_SORT_ORDER',
        'MODULE_PAYMENT_P_STRIPE_TESTMODE',
        'MODULE_PAYMENT_P_STRIPE_CURRENCY',
        'MODULE_PAYMENT_P_STRIPE_TESTING_SECRET_KEY',
        'MODULE_PAYMENT_P_STRIPE_TESTING_PUBLISHABLE_KEY',
        'MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_SECRET_KEY',
        'MODULE_PAYMENT_P_STRIPE_MERCHANT_LIVE_PUBLISHABLE_KEY',
        'MODULE_PAYMENT_P_STRIPE_USE_CVV',
        'MODULE_PAYMENT_P_STRIPE_SAVE_CC'
      );
  }

}
